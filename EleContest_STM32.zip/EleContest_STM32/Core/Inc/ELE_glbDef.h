/* @author: Antonio11111111
 * @date:   Mar 24, 2025
 * @description: * ALL THE GLOBAL DEFINITIONS MUST BE MANAGED&CONFIGURED
 *                IN THIS HEADER FILE.
 *               * All the comments must be written by English for the prevention of
 *                 abnormal display caused by different decoding mode.
 */

#ifndef ELECONTEST_STM32_ELE_GLBDEF_H
#define ELECONTEST_STM32_ELE_GLBDEF_H
/* Global includes */
#include <stdint.h>
#include <stdio.h>
/*Global definitions*/
#define u32 uint32_t
#define u16 uint16_t
#define u8 uint8_t
#define fp double

/* Personal definitions BEGIN */

/* Personal definitions END */

/* Personal variables BEGIN */

/* Personal variables END */

#endif //ELECONTEST_STM32_ELE_GLBDEF_H
